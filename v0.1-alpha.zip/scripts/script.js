"use strict";
// Algebra
var Algebra;
(function (Algebra) {
    Algebra.isEven = (value) => value % 2 == 0;
    Algebra.sum = (...values) => values.reduce((prev, x) => prev + x, 0);
    Algebra.difference = (...values) => values.reduce((prev, x) => prev - x);
    Algebra.product = (...values) => values.reduce((prev, x) => prev * x, 1);
    Algebra.remainder = (numerator, denominator) => numerator % denominator;
    Algebra.power = (base, exponent) => Math.pow(base, exponent);
    Algebra.root = (value, base) => Math.pow(value, 1 / base);
    Algebra.gcf = (...values) => {
        const absValues = values.map(Math.abs);
        for (let gcf = Math.min(...absValues); gcf > 1; --gcf) {
            if (absValues.every(x => gcf % x === 0))
                return gcf;
        }
        return 1;
    };
    Algebra.lcm = (...values) => {
        const absValues = values.map(Math.abs);
        const product = values.reduce((prev, x) => prev * x, 1);
        for (let lcm = Math.max(...absValues); lcm < product; ++lcm) {
            if (absValues.every(x => lcm % x == 0))
                return lcm;
        }
        return product;
    };
    Algebra.isFractional = (x) => Object.hasOwn(x, 'numerator') && Object.hasOwn(x, 'denominator');
    Algebra.isFraction = (x) => typeof x.numerator === "number";
    Algebra.fraction = (numerator, denominator) => {
        if (denominator == 0)
            return Infinity;
        if (numerator % denominator === 0)
            return numerator / denominator;
        const sign = (numerator < 0 != denominator < 0) ? -1 : 1;
        const numeratorAbs = Math.abs(numerator);
        const denominatorAbs = Math.abs(denominator);
        const fracGCF = Algebra.gcf(numeratorAbs, denominatorAbs);
        return {
            numerator: sign * numeratorAbs / fracGCF,
            denominator: denominatorAbs / fracGCF
        };
    };
    // mx²
    Algebra.monomialProduct = (x, m) => x * x * m;
    Algebra.radicalSquared = ({ coefficient, radicand }) => Algebra.monomialProduct(coefficient, radicand);
    Algebra.multiplyRadical = ({ coefficient, radicand }, scale) => ({ coefficient: coefficient * scale, radicand });
    Algebra.radical = (coefficient, radicand) => {
        if (radicand < 0)
            return NaN; // Complex
        if (radicand === 0)
            return 0;
        if (radicand === 1)
            return coefficient;
        // Simple
        const simpleRoot = Math.sqrt(radicand);
        if (Number.isInteger(simpleRoot))
            return coefficient * simpleRoot;
        const n = Algebra.radicalSquared({ coefficient, radicand });
        // Greatest perfect square
        const gps = Algebra.factors(n)
            .map(([common, [associated]]) => ({ coefficient: common, radicand: associated }))
            .reduce((prev, x) => {
            for (const [a, b] of [[x.coefficient, x.radicand], [x.radicand, x.coefficient]]) {
                if (a > (prev.coefficient * prev.coefficient)) {
                    const aRoot = Math.sqrt(a);
                    if (Number.isInteger(aRoot)) {
                        return { coefficient: aRoot, radicand: b };
                    }
                }
            }
            return prev;
        }, { coefficient: 1, radicand: n });
        return gps; // coefficient of 1 just means radical radicand
    };
    Algebra.radicalFraction = (numerator, denominator) => {
        const coefficient = Algebra.fraction(numerator.coefficient, denominator);
        if (Algebra.isFractional(coefficient)) {
            return {
                numerator: {
                    coefficient: coefficient.numerator,
                    radicand: numerator.radicand
                },
                denominator: coefficient.denominator
            };
        }
        else if (typeof coefficient === "number") {
            return { coefficient, radicand: numerator.radicand };
        }
        else {
            throw new Error("Not implemented");
        }
    };
    Algebra.fractionalRadical = (numerator, denominator) => {
        return Algebra.radicalFraction(Algebra.multiplyRadical(denominator, numerator), Algebra.radicalSquared(denominator));
    };
    Algebra.factors = (...values) => {
        const absValues = values.map(Math.abs);
        const factors = [[1, values]];
        const isOneValue = values.length === 1;
        for (let i = 2; (isOneValue ? i * i : i) <= Math.min(...absValues); ++i) {
            if (absValues.every(x => x % i == 0))
                factors.push([i, values.map(x => x / i)]);
        }
        return factors;
    };
    Algebra.isPrime = (n) => {
        const absValue = Math.abs(n);
        for (let i = 2; i * i < absValue; ++i) {
            if (absValue % i == 0)
                return false;
        }
        return true;
    };
    Algebra.compare = (a, b) => (a === b) ? '=' : (a > b) ? '>' : '<';
    Algebra.dotProduct = (a, b) => {
        if (a.length !== b.length)
            throw new Error("Cannot dot product different size arrays");
        return Algebra.sum(...a.map((a_i, i) => a_i * b[i]));
    };
    Algebra.sumOfSquares = (v) => Algebra.dotProduct(v, v);
    Algebra.vectorLength = (v) => Algebra.radical(1, Algebra.sumOfSquares(v));
    Algebra.vectorNormal = (v) => {
        const mag = Algebra.vectorLength(v);
        if (typeof mag === "number") {
            return v.map(x => Algebra.fraction(x, mag));
        }
        else {
            return v.map(x => Algebra.fractionalRadical(x, mag));
        }
    };
    Algebra.isNormalized = (v) => Math.abs(Algebra.sumOfSquares(v) - 1) <= 0.001;
    Algebra.isPythagorean = (...values) => {
        const last = values[-1];
        // a² + b² + c²      = 2c²
        // a² + b² + c² - c² = 2c² - c²
        // a² + b²           =  c²      (which defines pythagorean triple)
        return Algebra.sumOfSquares(values) === Algebra.monomialProduct(last, 2);
    };
})(Algebra || (Algebra = {}));
const fractionToString = (frac) => `${frac.numerator}/${frac.denominator}`;
const simplifiedFractionToString = (frac) => (typeof frac === "number") ? frac.toString() : fractionToString(frac);
const radicalToString = (rad) => (rad.coefficient !== 1 ? rad.coefficient : '') + `√${rad.radicand}`;
const simplifiedRadicalToString = (rad) => (typeof rad === "number") ? rad.toString() : radicalToString(rad);
const simplifiedRadicalFractionToString = (radFrac) => {
    if (typeof radFrac === "number") { // number
        return radFrac.toString();
    }
    else if (Algebra.isFractional(radFrac)) {
        if (Algebra.isFraction(radFrac)) { // Fraction
            return fractionToString(radFrac);
        }
        else { // RadicalFraction
            return `(${radicalToString(radFrac.numerator)})/${radFrac.denominator}`;
        }
    }
    else { // Radical
        return radicalToString(radFrac);
    }
};
// IO
const assertiveGetElementById = (id) => {
    const el = document.getElementById(id);
    if (el === null) {
        console.error(`${id} is either missing, not of the specified type, or doesn't have the expected ID, "${id}".`);
        throw new Error(`Cannot proceed without the element ${id}.`);
    }
    return el;
};
const toggleElementVisible = (element, isVisible) => element.classList.toggle("hidden", !isVisible);
const toggleParentVisible = (element, isVisible) => toggleElementVisible(element.parentElement, isVisible);
const toggleButtonEnabled = (button, isEnabled) => button.disabled = !isEnabled;
const inputA = assertiveGetElementById("input-a");
const inputB = assertiveGetElementById("input-b");
const inputC = assertiveGetElementById("input-c");
const abcContainer = assertiveGetElementById("abc-container");
const resultsUnary = assertiveGetElementById("results-unary");
const unaryOperations = ["quick-insights", "square", "sqrt"];
const unaryResults = Object.fromEntries(unaryOperations.map(what => [what, assertiveGetElementById(`unary-${what}`)]));
const setUnaryResult = (op, value) => unaryResults[op].value = value.toString();
unaryOperations.forEach((op) => setUnaryResult(op, '?'));
const unaryFactors = assertiveGetElementById("unary-factors");
const resultsBinary = assertiveGetElementById("results-binary");
const binaryOperations = ["comp", "sum", "diff", "prod", "div", "rem", "pow", "gcf", "lcm"];
const binaryResults = Object.fromEntries(binaryOperations.map(what => [what, assertiveGetElementById(`binary-${what}`)]));
const setBinaryResult = (op, value) => binaryResults[op].value = value.toString();
binaryOperations.forEach((op) => setBinaryResult(op, '?'));
const binaryFactors = assertiveGetElementById("binary-common-factors");
const resultsTernary = assertiveGetElementById("results-ternary");
const ternaryOperations = ["quick-insights", "vector", "vector-length", "vector-normal", "sum", "prod", "gcf", "lcm", "polynomial"];
const ternaryResults = Object.fromEntries(ternaryOperations.map(what => [what, assertiveGetElementById(`ternary-${what}`)]));
const setTernaryResult = (op, value) => ternaryResults[op].value = value.toString();
ternaryOperations.forEach((op) => setTernaryResult(op, '?'));
const ternaryFactors = assertiveGetElementById("ternary-common-factors");
const resultsContainer = assertiveGetElementById("results-container");
const runCalculationsButton = assertiveGetElementById("run-calculations-button");
const abcParamOptions = ['a', 'b', 'c'];
const abcParams = Object.fromEntries(abcParamOptions.map((key) => [key, Array.from(document.querySelectorAll(`output.param.${key}`))]));
const markParamsDirty = (key, isDirty = true) => {
    abcParams[key].forEach(el => el.classList.toggle("dirty", isDirty));
};
const setParamsValues = (key, value) => {
    abcParams[key].forEach(el => el.value = value);
};
abcParamOptions.forEach(key => setParamsValues(key, key.toUpperCase()));
const setFactors = (element, header, factors) => {
    element.innerHTML = "";
    // Header row
    {
        const row = document.createElement('tr');
        element.appendChild(row);
        {
            const factorCell = document.createElement('th');
            row.appendChild(factorCell);
        }
        for (let i = 0; i < header.length; ++i) {
            const cell = document.createElement('th');
            row.appendChild(cell);
            cell.innerText = `${header[i]}`;
            cell.classList.add(abcParamOptions[i]);
        }
    }
    for (const factor of factors) {
        const [fac, parts] = factor;
        const row = document.createElement('tr');
        element.appendChild(row);
        const factorCell = document.createElement('th');
        row.appendChild(factorCell);
        factorCell.innerText = `${fac}`;
        factorCell.classList.add("result");
        for (let i = 0; i < parts.length; ++i) {
            const cell = document.createElement('td');
            row.appendChild(cell);
            cell.innerHTML = `${parts[i]}`;
        }
    }
};
let currentInputCount = 0; // At time of input
let currentValues = abcParamOptions.map(x => x.toUpperCase()); // At time of calculation
// Disable fractional inputs
[inputA].forEach(input => input.addEventListener("keydown", (event) => {
    if (event.key === '.')
        event.preventDefault();
}));
abcContainer.addEventListener("input", () => {
    var _a, _b, _c;
    let values = [inputA, inputB, inputC]
        .map(el => el.value)
        .filter(value => value !== "");
    const inputCount = values.length;
    const changes = abcParamOptions.map((_, i) => values[i] !== currentValues[i]);
    abcParamOptions.forEach((x, i) => markParamsDirty(x, changes[i]));
    const isResultIdentical = changes.every(x => !x);
    toggleButtonEnabled(runCalculationsButton, inputCount !== 0 && !isResultIdentical);
    if (inputCount === currentInputCount)
        return; // Only continue if the number of inputs changed
    currentInputCount = inputCount;
    [inputA.value, inputB.value, inputC.value] = [(_a = values[0]) !== null && _a !== void 0 ? _a : "", (_b = values[1]) !== null && _b !== void 0 ? _b : "", (_c = values[2]) !== null && _c !== void 0 ? _c : ""];
    toggleParentVisible(inputB, inputCount >= 1);
    toggleParentVisible(inputC, inputCount >= 2);
    toggleElementVisible(resultsUnary, inputCount === 1);
    toggleElementVisible(resultsBinary, inputCount === 2);
    toggleElementVisible(resultsTernary, inputCount === 3);
});
const runCalculationsUnary = ([a]) => {
    console.log(`calculate unary for ${a}`);
    const evenOrOdd = Algebra.isEven(a) ? "even" : "odd";
    const compositeOrPrime = Algebra.isPrime(a) ? "prime" : "composite";
    setUnaryResult("quick-insights", `an ${evenOrOdd} ${compositeOrPrime}`);
    setUnaryResult("square", Algebra.power(a, 2));
    setUnaryResult("sqrt", simplifiedRadicalToString(Algebra.radical(1, a)));
    setFactors(unaryFactors, [a], Algebra.factors(a));
};
const runCalculationsBinary = ([a, b]) => {
    6;
    console.log(`calculate binary for ${a}, ${b}`);
    setBinaryResult("comp", Algebra.compare(a, b));
    setBinaryResult("sum", Algebra.sum(a, b));
    setBinaryResult("diff", Algebra.difference(a, b));
    setBinaryResult("prod", Algebra.product(a, b));
    setBinaryResult("div", simplifiedFractionToString(Algebra.fraction(a, b)));
    setBinaryResult("rem", Algebra.remainder(a, b));
    setBinaryResult("pow", Algebra.power(a, b));
    setBinaryResult("gcf", Algebra.gcf(a, b));
    setBinaryResult("lcm", Algebra.lcm(a, b));
    setFactors(binaryFactors, [a, b], Algebra.factors(a, b));
};
const runCalculationsTernary = ([a, b, c]) => {
    console.log(`calculate ternary for ${a}, ${b}, ${c}`);
    const v = [a, b, c];
    const normalizedVectorOrNot = Algebra.isNormalized(v) ? "a unit" : "an unnormalized";
    const pythagoreanTripleOrNot = Algebra.isPythagorean(a, b, c) ? "" : "not";
    setTernaryResult("quick-insights", `${normalizedVectorOrNot} vector ${pythagoreanTripleOrNot} composing a pythagorean triple`);
    setTernaryResult("vector", `(${v.join(', ')})`);
    setTernaryResult("vector-length", simplifiedRadicalToString(Algebra.vectorLength(v)));
    setTernaryResult("vector-normal", `(${Algebra.vectorNormal(v).map(simplifiedRadicalFractionToString).join(', ')})`);
    setTernaryResult("sum", Algebra.sum(a, b, c));
    setTernaryResult("prod", Algebra.product(a, b, c));
    setTernaryResult("gcf", Algebra.gcf(a, b, c));
    setTernaryResult("lcm", Algebra.lcm(a, b, c));
    setFactors(ternaryFactors, [a, b, c], Algebra.factors(a, b, c));
};
runCalculationsButton.addEventListener("click", () => {
    abcParamOptions.forEach(key => markParamsDirty(key, false));
    currentValues = [inputA, inputB, inputC].map(x => x.value).filter(value => value !== "");
    const currentNumValues = currentValues.map(value => Number(value));
    abcParamOptions.forEach((key, index) => { var _a; return setParamsValues(key, "" + ((_a = currentNumValues[index]) !== null && _a !== void 0 ? _a : key.toUpperCase())); });
    toggleButtonEnabled(runCalculationsButton, false);
    switch (currentInputCount) {
        case 0:
            console.log("error");
            break; // Shouldn't be possible when the button is disabled
        case 1:
            runCalculationsUnary(currentNumValues);
            break;
        case 2:
            runCalculationsBinary(currentNumValues);
            break;
        case 3:
            runCalculationsTernary(currentNumValues);
            break;
    }
});
